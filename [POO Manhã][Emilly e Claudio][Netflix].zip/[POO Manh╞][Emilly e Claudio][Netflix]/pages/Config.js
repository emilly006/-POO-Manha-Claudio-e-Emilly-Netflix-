import './Config.css'
import MenuLateral from '../components/MenuLateral'

function Config(){
    return(

        <div>
            <MenuLateral />
        </div>
        
    )

}

export default Config;